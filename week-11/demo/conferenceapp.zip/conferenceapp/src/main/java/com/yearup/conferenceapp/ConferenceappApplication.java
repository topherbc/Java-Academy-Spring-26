package com.yearup.conferenceapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConferenceappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConferenceappApplication.class, args);
	}

}
